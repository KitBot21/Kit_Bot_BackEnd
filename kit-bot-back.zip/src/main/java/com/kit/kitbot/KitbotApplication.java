package com.kit.kitbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitbotApplication.class, args);
	}

}
